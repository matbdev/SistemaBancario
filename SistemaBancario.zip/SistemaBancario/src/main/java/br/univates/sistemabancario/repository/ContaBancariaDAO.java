package br.univates.sistemabancario.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;

import br.univates.alexandria.exceptions.CpfInvalidoException;
import br.univates.alexandria.exceptions.DataBaseException;
import br.univates.alexandria.exceptions.DuplicatedKeyException;
import br.univates.alexandria.exceptions.RecordNotFoundException;
import br.univates.alexandria.exceptions.RecordNotReady;
import br.univates.alexandria.interfaces.IDao;
import br.univates.alexandria.interfaces.IFilter;
import br.univates.alexandria.models.CPF;
import br.univates.alexandria.models.Pessoa;
import br.univates.alexandria.repository.DataBaseConnectionManager;
import br.univates.sistemabancario.exceptions.SaldoInvalidoException;
import br.univates.sistemabancario.service.ContaBancaria;
import br.univates.sistemabancario.service.ContaBancariaEspecial;
import br.univates.sistemabancario.service.Numero;

public class ContaBancariaDAO implements IDao<ContaBancaria, Integer> {

    public ContaBancariaDAO() {
    }

    /**
     * {@inheritedDoc}
     */
    @Override
    public void create(ContaBancaria cb, DataBaseConnectionManager db) throws DuplicatedKeyException, DataBaseException {
        if (db == null) {
            throw new DataBaseException("A conexão com o banco de dados não pode ser nula.");
        }
        try {
            String tipoContaStr = (cb.getTipoConta().equals("ContaBancaria")) ? "N" : "E";
            db.runPreparedSQL("INSERT INTO conta VALUES (?,?,?,?,?);",
                    cb.getNumeroContaInt(), tipoContaStr, cb.getLimite(), cb.getPessoa().getCpfNumbers(),
                    cb.getSaldo());

        } catch (DataBaseException e) {
            throw new DuplicatedKeyException();
        }
    }

    /**
     * Busca o maior número de conta existente no banco de dados.
     * @param db - conexão de banco de dados a ser usada.
     * @return - maior número de conta, ou 0 se a tabela estiver vazia.
     * @throws DataBaseException - erro ao consultar o banco.
     */
    private int getMaxNumeroConta(DataBaseConnectionManager db) throws DataBaseException {
        int maxNumero = 0;
        try (ResultSet rs = db.runQuerySQL("SELECT MAX(numero_conta) AS max_num FROM conta;")) {
            if (rs.next()) {
                maxNumero = rs.getInt("max_num");
            }
        } catch (SQLException e) {
            // Em caso de não houver registros
        }
        return maxNumero;
    }

    /**
     * {@inheritDoc}
     * 
     * Este método gerencia sua própria conexão e a fecha após o uso.
     */
    @Override
    public void create(ContaBancaria cb) throws DuplicatedKeyException, DataBaseException {
        DataBaseConnectionManager db = null;
        try {
            db = DAOFactory.getDataBaseConnectionManager();

            // Define o número da conta como o maior cadastrado + 1
            int maxNum = this.getMaxNumeroConta(db);
            Numero novoNumero = new Numero(maxNum + 1);
            cb.setNumeroConta(novoNumero); // Esse método só pode ser chamado uma vez, quando não há número

            this.create(cb, db);
        } finally {
            // Fecha a conexão
            if (db != null) {
                db.closeConnection();
            }
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ContaBancaria read(Integer numero) throws RecordNotFoundException, DataBaseException {
        ContaBancaria contaEncontrada = null;
        DataBaseConnectionManager db = null;
        IDao<Pessoa, CPF> cdao = DAOFactory.getCorrentistaDAO();

        try {
            db = DAOFactory.getDataBaseConnectionManager();

            try (ResultSet rs = db.runPreparedQuerySQL("SELECT * FROM conta where numero_conta = ?;",
                    numero)) {

                if (rs.isBeforeFirst()) {
                    rs.next();
                    String tipoContaStr = rs.getString("tipo_conta");
                    char tipoConta = tipoContaStr.charAt(0);
                    double limiteConta = rs.getDouble("limite_conta");
                    String cpfCorrentista = rs.getString("cpf_correntista");
                    double saldo = rs.getDouble("saldo");

                    CPF cpf = new CPF(cpfCorrentista);
                    Pessoa pEncontrada;
                    try {
                        pEncontrada = cdao.read(cpf);
                    } catch (RecordNotFoundException e) {
                        throw new RecordNotFoundException();
                    }

                    if (tipoConta == 'E') {
                        contaEncontrada = new ContaBancariaEspecial(pEncontrada, limiteConta, 0, numero);
                        if (saldo > 0)
                            contaEncontrada.depositaValor(saldo);
                        else if (saldo < 0)
                            contaEncontrada.sacarValor(Math.abs(saldo));
                    } else {
                        contaEncontrada = new ContaBancaria(pEncontrada, saldo, numero);
                    }
                }
            } catch (SQLException | CpfInvalidoException | SaldoInvalidoException e) {
                throw new RecordNotFoundException();
            }

        } finally {
            // Fecha a conexão
            if (db != null) {
                db.closeConnection();
            }
        }

        if (contaEncontrada == null) {
            throw new RecordNotFoundException();
        }
        return contaEncontrada;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ArrayList<ContaBancaria> readAll() throws RecordNotReady, DataBaseException {
        ArrayList<ContaBancaria> cbList = new ArrayList<>();
        DataBaseConnectionManager db = null;
        CorrentistaDAO cdao = new CorrentistaDAO();

        try {
            db = DAOFactory.getDataBaseConnectionManager();

            try (ResultSet rs = db.runQuerySQL("SELECT * FROM conta;")) {

                if (rs.isBeforeFirst()) {
                    rs.next();
                    while (!rs.isAfterLast()) {
                        int numeroConta = rs.getInt("numero_conta");
                        String tipoContaStr = rs.getString("tipo_conta");
                        char tipoConta = tipoContaStr.charAt(0);
                        double limiteConta = rs.getDouble("limite_conta");
                        String cpfCorrentista = rs.getString("cpf_correntista");
                        double saldo = rs.getDouble("saldo");

                        ContaBancaria cb;
                        CPF cpf = new CPF(cpfCorrentista);

                        Pessoa pEncontrada = cdao.read(cpf);

                        if (tipoConta == 'E') {
                            cb = new ContaBancariaEspecial(pEncontrada, limiteConta, 0, numeroConta);
                            if (saldo > 0)
                                cb.depositaValor(saldo);
                            else if (saldo < 0)
                                cb.sacarValor(Math.abs(saldo));
                        } else {
                            cb = new ContaBancaria(pEncontrada, saldo, numeroConta);
                        }
                        cbList.add(cb);
                        rs.next();
                    }
                }
                Collections.sort(cbList);
            } catch (SQLException | CpfInvalidoException | SaldoInvalidoException
                    | RecordNotFoundException e) {
                throw new RecordNotReady();
            }

        } finally {
            // Fecha a conexão
            if (db != null) {
                db.closeConnection();
            }
        }
        return cbList;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ArrayList<ContaBancaria> readAll(IFilter<ContaBancaria> filtro) throws RecordNotReady, DataBaseException {
        ArrayList<ContaBancaria> listaParcial = new ArrayList<>();
        for (ContaBancaria cb : this.readAll()) {
            if (filtro.isAccept(cb)) {
                listaParcial.add(cb);
            }
        }
        return listaParcial;
    }

    /**
     * {@inheritDoc}
     */
    public void update(ContaBancaria cb, DataBaseConnectionManager db) throws RecordNotFoundException, DataBaseException {
        if (db == null) {
            throw new DataBaseException("A conexão com o banco de dados não pode ser nula.");
        }
        db.runPreparedSQL("UPDATE conta SET saldo = ? WHERE numero_conta = ?",
                cb.getSaldo(), cb.getNumeroContaInt());
    }

    /**
     * {@inheritDoc}
     * 
     * Este método gerencia sua própria conexão e a fecha após o uso.
     */
    @Override
    public void update(ContaBancaria cb) throws RecordNotFoundException, DataBaseException {
        DataBaseConnectionManager db = null;
        try {
            db = DAOFactory.getDataBaseConnectionManager();
            this.update(cb, db);
        } finally {
            // Fecha a conexão
            if (db != null) {
                db.closeConnection();
            }
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void delete(ContaBancaria cb) throws RecordNotFoundException, DataBaseException {
        DataBaseConnectionManager db = null;
        try {
            db = DAOFactory.getDataBaseConnectionManager();

            db.runPreparedSQL("DELETE FROM conta WHERE numero_conta = ?",
                    cb.getNumeroContaInt());

        } finally {
            // Fecha a conexão
            if (db != null) {
                db.closeConnection();
            }
        }
    }
}