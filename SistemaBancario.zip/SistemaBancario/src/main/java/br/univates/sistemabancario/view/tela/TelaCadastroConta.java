package br.univates.sistemabancario.view.tela;

import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import br.univates.alexandria.exceptions.DataBaseException;
import br.univates.alexandria.exceptions.RecordNotReady;
import br.univates.alexandria.interfaces.IDao;
import br.univates.alexandria.models.CPF;
import br.univates.alexandria.models.Pessoa;
import br.univates.alexandria.util.Messages;
import br.univates.sistemabancario.service.ContaBancaria;
import br.univates.sistemabancario.service.ContaBancariaEspecial;
import br.univates.sistemabancario.view.elements.PessoaComboBox;

/**
 * Tela responsável por realizar o cadastro de uma conta bancária
 * 
 * @author mateus.brambilla
 */
public class TelaCadastroConta extends javax.swing.JDialog {
        private final IDao<Pessoa, CPF> cdao;
        private final IDao<ContaBancaria, Integer> cbdao;

        // Componentes
        private JButton botaoCadastro;
        private PessoaComboBox cbCorrentista;
        private JLabel labelCorrentista;
        private JLabel labelLimite;
        private JLabel labelSaldo;
        private JLabel labelSuccessError;
        private JLabel labelTitulo;
        private JTextField tfLimite;
        private JTextField tfSaldo;

        /**
         * Creates new form FrameCadastroCorrentista
         * 
         * @param parent - um JFrame
         * @param cdao   - instancia de CorrentistaDAO
         * @param cbdao  - instancia de ContaBancariaDAO
         */
        public TelaCadastroConta(JFrame parent, IDao<Pessoa, CPF> cdao, IDao<ContaBancaria, Integer> cbdao) {
                super(parent, "Cadastro de Conta Bancária", true);
                this.cdao = cdao;
                this.cbdao = cbdao;

                initComponents();
                setLocationRelativeTo(parent);
        }

        /**
         * Método que inicializa os componentes da tela
         * 
         * @param cdao - dao de correntista para combobox de pessoa
         */
        private void initComponents() {
                try {
                        labelCorrentista = new javax.swing.JLabel();
                        botaoCadastro = new javax.swing.JButton();
                        labelTitulo = new javax.swing.JLabel();
                        tfSaldo = new javax.swing.JTextField();
                        labelSaldo = new javax.swing.JLabel();
                        labelSuccessError = new javax.swing.JLabel();
                        cbCorrentista = new PessoaComboBox(this.cdao);
                        labelLimite = new javax.swing.JLabel();
                        tfLimite = new javax.swing.JTextField();

                        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
                        setTitle("Correntistas");
                        setAlwaysOnTop(true);
                        setBackground(new java.awt.Color(51, 51, 51));
                        setBounds(new java.awt.Rectangle(0, 0, 0, 0));
                        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

                        labelCorrentista.setText("Informe o correntista:");

                        botaoCadastro.setBackground(new java.awt.Color(0, 0, 51));
                        botaoCadastro.setForeground(new java.awt.Color(255, 255, 255));
                        botaoCadastro.setText("Cadastrar");
                        botaoCadastro.setAutoscrolls(true);
                        botaoCadastro.addActionListener(evt -> botaoCadastroActionPerformed(evt));

                        labelTitulo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
                        labelTitulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        labelTitulo.setText("Cadastro de Conta Bancária");

                        labelSaldo.setLabelFor(tfSaldo);
                        labelSaldo.setText("Informe o saldo inicial (opcional):");
                        labelLimite.setText("Em caso de conta especial, informe o limite (opcional):");

                        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
                        getContentPane().setLayout(layout);
                        layout.setHorizontalGroup(
                                        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(labelTitulo,
                                                                        javax.swing.GroupLayout.Alignment.TRAILING,
                                                                        javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                        javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                        Short.MAX_VALUE)
                                                        .addGroup(layout.createSequentialGroup()
                                                                        .addGap(18, 18, 18)
                                                                        .addGroup(layout.createParallelGroup(
                                                                                        javax.swing.GroupLayout.Alignment.LEADING)
                                                                                        .addGroup(layout.createSequentialGroup()
                                                                                                        .addComponent(labelLimite)
                                                                                                        .addContainerGap(
                                                                                                                        javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                                        Short.MAX_VALUE))
                                                                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING,
                                                                                                        layout
                                                                                                                        .createSequentialGroup()
                                                                                                                        .addGroup(layout
                                                                                                                                        .createParallelGroup(
                                                                                                                                                        javax.swing.GroupLayout.Alignment.TRAILING)
                                                                                                                                        .addComponent(tfLimite,
                                                                                                                                                        javax.swing.GroupLayout.Alignment.LEADING)
                                                                                                                                        .addComponent(labelSaldo,
                                                                                                                                                        javax.swing.GroupLayout.Alignment.LEADING,
                                                                                                                                                        javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                                                                        javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                                                                        Short.MAX_VALUE)
                                                                                                                                        .addComponent(cbCorrentista,
                                                                                                                                                        0,
                                                                                                                                                        javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                                                                        Short.MAX_VALUE)
                                                                                                                                        .addComponent(labelCorrentista,
                                                                                                                                                        javax.swing.GroupLayout.Alignment.LEADING,
                                                                                                                                                        javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                                                                        javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                                                                        Short.MAX_VALUE)
                                                                                                                                        .addComponent(tfSaldo)
                                                                                                                                        .addGroup(layout.createSequentialGroup()
                                                                                                                                                        .addGap(0, 0, Short.MAX_VALUE)
                                                                                                                                                        .addComponent(labelSuccessError,
                                                                                                                                                                        javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                                                                                        272,
                                                                                                                                                                        javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                                                                                                        .addGap(18, 18, 18)
                                                                                                                                                        .addComponent(botaoCadastro)))
                                                                                                                        .addGap(18, 18, 18)))));
                        layout.setVerticalGroup(
                                        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(layout.createSequentialGroup()
                                                                        .addGap(15, 15, 15)
                                                                        .addComponent(labelTitulo)
                                                                        .addGap(12, 12, 12)
                                                                        .addComponent(labelCorrentista)
                                                                        .addPreferredGap(
                                                                                        javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                                        .addComponent(cbCorrentista,
                                                                                        javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                        javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                        javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addGap(18, 18, 18)
                                                                        .addComponent(labelSaldo,
                                                                                        javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                        10,
                                                                                        javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addPreferredGap(
                                                                                        javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                                        .addComponent(tfSaldo,
                                                                                        javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                        javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                        javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addPreferredGap(
                                                                                        javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                                        .addPreferredGap(
                                                                                        javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                                        .addPreferredGap(
                                                                                        javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                                        .addComponent(labelLimite)
                                                                        .addPreferredGap(
                                                                                        javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                                        .addComponent(tfLimite,
                                                                                        javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                        javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                        javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addGroup(layout.createParallelGroup(
                                                                                        javax.swing.GroupLayout.Alignment.LEADING)
                                                                                        .addGroup(layout.createSequentialGroup()
                                                                                                        .addGap(18, 18, 18)
                                                                                                        .addComponent(labelSuccessError,
                                                                                                                        javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                                        52,
                                                                                                                        javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                                                        .addContainerGap(
                                                                                                                        15,
                                                                                                                        Short.MAX_VALUE))
                                                                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING,
                                                                                                        layout
                                                                                                                        .createSequentialGroup()
                                                                                                                        .addPreferredGap(
                                                                                                                                        javax.swing.LayoutStyle.ComponentPlacement.RELATED,
                                                                                                                                        javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                                                        Short.MAX_VALUE)
                                                                                                                        .addComponent(botaoCadastro)
                                                                                                                        .addGap(29, 29, 29)))));

                        getAccessibleContext().setAccessibleName("Contas Bancárias");

                        pack();
                } catch (DataBaseException | RecordNotReady e) {
                        Messages.errorMessage(e);
                        dispose();
                }
        }

        /**
         * Método que realiza o cadastro quando o botão é clicado
         * 
         * @param evt - não utilizado
         */
        private void botaoCadastroActionPerformed(@SuppressWarnings("unused") java.awt.event.ActionEvent evt) {
                try {
                        Pessoa correntista = (Pessoa) this.cbCorrentista.getSelectedItem();
                        if (correntista == null) {
                                throw new Exception("Por favor, selecione um correntista.");
                        }

                        String saldoStr = this.tfSaldo.getText();
                        String limiteStr = this.tfLimite.getText();

                        // TypeCasting
                        double saldo = saldoStr.isBlank() ? 0.0 : Double.parseDouble(saldoStr);
                        double limite = limiteStr.isBlank() ? 0.0 : Double.parseDouble(limiteStr);

                        ContaBancaria cb;

                        if (limite != 0) { // conta especial
                                cb = new ContaBancariaEspecial(correntista, limite, saldo);
                        } else { // conta normal
                                cb = new ContaBancaria(correntista, saldo);
                        }

                        cbdao.create(cb);

                        this.labelSuccessError.setText("Conta bancária adicionada com sucesso!");
                        this.labelSuccessError.setForeground(Color.green);
                        
                        this.tfSaldo.setText("");
                        this.tfLimite.setText("");

                        this.cbCorrentista.setSelectedIndex(0);

                } catch (NumberFormatException nfe) {
                        this.labelSuccessError
                                        .setText("<html>Erro: Saldo, número e limite devem ser valores numéricos válidos.</html>");
                        this.labelSuccessError.setForeground(Color.red);
                } catch (Exception e) {
                        this.labelSuccessError.setText("<html>Erro: " + e.getMessage() + "</html>");
                        this.labelSuccessError.setForeground(Color.red);
                }
        }
}
