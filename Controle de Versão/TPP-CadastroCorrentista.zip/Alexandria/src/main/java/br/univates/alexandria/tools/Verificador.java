package br.univates.alexandria.tools;

import java.util.ArrayList;

/**
 * Fornece métodos verificadores auxiliares
 * @author mateus.brambilla
 */
public class Verificador {
    /**
     * Método auxiliar que verifica se o input está vazio
     * @param text - texto informado
     * @param message - mensagem em caso de erro
     */
    public static void verificaVazio(String text, String message) throws IllegalArgumentException{
        if(text.isBlank()){
            throw new IllegalArgumentException(message);
        }
    }
    
    /**
     * Método auxiliar que verifica se o input está vazio
     * @param text - texto informado
     * @param message - mensagem em caso de erro
     */
    public static void verificaVazio(char text, String message) throws IllegalArgumentException{
        if(Character.isWhitespace(text)){
            throw new IllegalArgumentException(message);
        }
    }
    
    /**
     * Método auxiliar que verifica se o input está vazio
     * @param array - lista informada
     * @param message - mensagem em caso de erro
     */
    public static void verificaVazio(ArrayList<?> array, String message) throws IllegalArgumentException{
        if(array.isEmpty()){
            throw new IllegalArgumentException(message);
        }
    }
}
