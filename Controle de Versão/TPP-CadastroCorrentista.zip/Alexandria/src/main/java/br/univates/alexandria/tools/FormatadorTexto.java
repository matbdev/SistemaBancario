package br.univates.alexandria.tools;

/**
 * Método que fornece conversores de texto
 * @author mateus.brambilla
 */
public class FormatadorTexto {
    
    /**
     * Método que recebe uma string e formata para que a primeira letra seja maiúscula
     * @param text - string recebida
     * @return  - string com primeiro caractere em maiúsculo
     */
    public static String converteCapitalize(String text){
        if(text.isBlank())
            throw new IllegalArgumentException("Título inválido fornecido");

        // Primeira letra em maiúsculo
        String trimmedText = text.trim();
        String sub = trimmedText.substring(0, 1).toUpperCase();
        String resto = trimmedText.substring(1).toLowerCase();

        return sub + resto;
    }
    
    /**
     * Método que recebe um text e retorna ele sem caracteres, só números
     * @param text - texto com caracteres completos
     * @return - dígitos numéricos
     */
    public static String limparNumeros(String text) {
        return text.replaceAll("[^0-9]", "");
    }
}
