package br.univates.sistemabancario.persist;

import br.univates.alexandria.models.CPF;
import br.univates.alexandria.models.Pessoa;
import java.util.ArrayList;

/**
 * Classe que lida com a persistência para cadastro de correntista
 * @author mateus.brambilla
 */
public class CorrentistaDAO {
        private static final ArrayList<Pessoa> pList = new ArrayList<>();
    
    // Getters
    public ArrayList<Pessoa> readAll(){
        return pList;
    }
    
    public Pessoa read(String cpf){
        Pessoa pEncontrada = null;
        for(Pessoa p : pList){
            if(p.getCpfNumbers().equals(cpf) | p.getCpfNumbers().equals(cpf)){
                pEncontrada = p;
            }
        }
        return pEncontrada;
    }
   
    public Pessoa read(CPF cpf){
        Pessoa pEncontrada = null;
        for(Pessoa p : pList){
            if(p.getCPF().equals(cpf)){
                pEncontrada = p;
            }
        }
        return pEncontrada;
    }
  
    public void create(Pessoa p){
        pList.add(p);
    }
}
