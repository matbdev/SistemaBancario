package br.univates.sistemabancario.view;

import br.univates.alexandria.models.Pessoa;
import br.univates.alexandria.tools.Messages;
import br.univates.alexandria.view.Menu;
import br.univates.sistemabancario.persist.CorrentistaDAO;
import java.util.ArrayList;
import javax.swing.*;


/**
 * Menu principal da aplicação
 * @author mateus.brambilla
 */
public class MenuPrincipal extends Menu {
    private final CorrentistaDAO cdao = new CorrentistaDAO();
    
    public MenuPrincipal(){
        setTitulo("V1 - SISTEMA BANCÁRIO");
        adicionarOpcoes();
    }
    
    private void adicionarOpcoes(){
        addOption("Cadastrar Correntista", 'c', () -> cadastrarCorrentista());
        addOption("Visualizar Correntistas", 'v', () -> visualizarCorrentistas());
        addOption("Manusear Contas Bancárias", 'm', () -> manusearContas());
        addLastOption();
    }
    
    @Override
    public void addLastOption(){
        addOption(
                "Sair do sistema", 
                'x', 
                () -> {Messages.infoMessage("Saindo do programa..."); System.exit(0);}
        );
    }
    
    private void cadastrarCorrentista(){
        JDialog dialog = new DialogCadastroCorrentista(null);
        dialog.setVisible(true);
    }
    
    private void visualizarCorrentistas(){
        ArrayList<Pessoa> cList = cdao.readAll();
        
        if(cList.isEmpty()){
            Messages.infoMessage("Não há correntistas cadastrados");
        }else{
            StringBuilder sb = new StringBuilder();

            for (Pessoa p : cList) {
                sb.append("Correntista: ").append(p.getNome());
                sb.append("\nCPF: ").append(p.getCpfFormatado());
                sb.append("\nEndereco: ").append(p.getEndereco());
                sb.append("\n\n");
            }

            Messages.infoMessage(sb.toString());
        }
    }
    
    private void manusearContas(){
        MenuContas mc = new MenuContas();
        mc.gerarMenu();
    }
}
