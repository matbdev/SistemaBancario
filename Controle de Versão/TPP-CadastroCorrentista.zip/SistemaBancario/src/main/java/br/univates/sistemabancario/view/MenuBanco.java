package br.univates.sistemabancario.view;

import br.univates.alexandria.exceptions.NullInputException;
import br.univates.alexandria.exceptions.SaldoInvalidoException;
import br.univates.alexandria.tools.Inputs;
import br.univates.alexandria.tools.Messages;
import br.univates.alexandria.view.Menu;
import br.univates.sistemabancario.business.ContaBancaria;

/**
 * Classe que herda de menu, representando a view do nosso banco
 * @author mateus.brambilla
 */
public class MenuBanco extends Menu {
    private final ContaBancaria cb;
    /**
     * Construtor que recebe cpf, nome, endereco e saldo e instancia classe
     * @param cb - conta bancária já instanciada
     */
    public MenuBanco(ContaBancaria cb){
        this.cb = cb;
        adicionarOpcoes();
    }
    
    // Getter
    public ContaBancaria getContaBancaria(){
        return this.cb;
    }
    
    /**
     * Construtor que recebe uma conta bancária 
     * Adiciona as opções do menu
     * @param contaBancaria - objeto instanciado de ContaBancaria
     */
    private void adicionarOpcoes(){
        addOption("Depositar valor", 'd', () -> depositarValor());
        addOption("Sacar valor", 's', () -> sacarValor());
        addOption("Verificar status", 'v', () -> verificarStatus());
        addLastOption();
    }
    
    /**
     * Método que realiza um depósito
     */
    public void depositarValor(){
        try{
            double dQtde = Inputs.Double(
                    "Infome a quantidade a ser depositada",
                    "DEPÓSITO"
            );
            
            this.cb.depositaValor(dQtde);
            verificarStatus();
                    
        }catch(SaldoInvalidoException e){
            Messages.errorMessage(e);
        }catch(NullInputException e){
            Messages.infoMessage("Cancelando operação...");
        }
    }
    
    /**
     * Método que realiza um saque
     */
    public void sacarValor(){
        try{
            double dQtde = Inputs.Double(
                    "Informe a quantidade a ser sacada",
                    "DEPÓSITO"
            );
                    
            this.cb.sacarValor(dQtde);
            verificarStatus();
        }catch(SaldoInvalidoException e){
            Messages.errorMessage(e);
        }catch(NullInputException e){
            Messages.infoMessage("Cancelando operação...");
        }
    }
    
    /**
     * Método que informa o status da conta
     */
    public void verificarStatus(){
        Messages.infoMessage(this.cb.consultarStatus());
    }
}
