package br.univates.sistemabancario.view;

import br.univates.alexandria.tools.Messages;

/**
 * Tela que serve para garantir estrutura da arquitetura do projeto
 * @author mateus.brambilla
 */
public class TelaPrincipal {
    public void iniciarMenuContas(){
        MenuPrincipal m = new MenuPrincipal();
        m.gerarMenu();
        Messages.infoMessage("Saindo da aplicação...");
    }
}
