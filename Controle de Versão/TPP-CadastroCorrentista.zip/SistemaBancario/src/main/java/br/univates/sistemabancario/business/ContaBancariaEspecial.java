package br.univates.sistemabancario.business;

import br.univates.alexandria.exceptions.SaldoInvalidoException;
import br.univates.alexandria.models.Pessoa;

/**
 * Classe que simula uma conta especial
 * Essa conta possui um limite máximo de saldo negativo
 * @author mateus.brambilla
 */
public class ContaBancariaEspecial extends ContaBancaria {
    // Constructor overload
    public ContaBancariaEspecial(String cpf, String nome, String endereco, double saldo, double limite) throws SaldoInvalidoException{
        super(cpf, nome, endereco, saldo);
        setLimite(limite);
    }
    
    public ContaBancariaEspecial(String cpf, String nome, String endereco, double limite){
        super(cpf, nome, endereco);
        setLimite(limite);
    }
    
    public ContaBancariaEspecial(Pessoa p, double saldo, double limite) throws SaldoInvalidoException{
        super(p, saldo);
        setLimite(limite);
    }
    
    public ContaBancariaEspecial(Pessoa p, double limite){
        super(p);
        setLimite(limite);
    }
}
