package br.univates.sistemabancario.business;

import br.univates.alexandria.exceptions.SaldoInvalidoException;
import br.univates.alexandria.models.Pessoa;

/**
 * Classe responsável por simular uma conta bancária simples
 * @author mateus.brambilla
 */
public class ContaBancaria {
    private final Pessoa pessoa;
    private double saldo = 0;
    private double limite = 0;
    private static int proxNConta = 100000;
    private final int nConta;
    
    // Constructor overload
    public ContaBancaria(String cpf, String nome, String endereco, double saldo) throws SaldoInvalidoException{
        verificaSaldo(saldo, "O saldo é menor que 0, informe uma quantia válida.");
        this.pessoa = new Pessoa(cpf, nome, endereco);
        this.saldo = saldo;
        this.nConta = proxNConta++;
    }
    
    public ContaBancaria(String cpf, String nome, String endereco){
        this.pessoa = new Pessoa(cpf, nome, endereco);
        this.nConta = proxNConta++;
    }
    
    public ContaBancaria(Pessoa p){
        this.pessoa = p;
        this.nConta = proxNConta++;
    }
    
    public ContaBancaria(Pessoa p, double saldo){
        this.pessoa = p;
        this.saldo = saldo;
        this.nConta = proxNConta++;
    }
    
    /**
     * Método auxiliar que verifica o saldo informado/resultado
     * @param saldo - saldo informado
     * @param message - mensagem a ser exibida
     * @throws IllegalArgumentException - em caso de saldo inválido
     */
    private void verificaSaldo(double saldo, String message) throws SaldoInvalidoException{
        if(saldo < this.limite){
            throw new SaldoInvalidoException(message);
        }
    } 
    
    /**
     * Método que realiza o depósito de um valor
     * Verifica o valor informado e o resultante
     * @param saldo - saldo a ser recebido
     * @throws SaldoInvalidoException - em caso de saldo inválido
     */
    public void depositaValor(double saldo) throws SaldoInvalidoException{
        verificaSaldo(saldo, "O saldo é menor que 0, informe uma quantia válida.");
        double novoSaldo = this.saldo + saldo;
        
        this.saldo = novoSaldo;
    }
    
    /**
     * Método que realiza o saque de um valor
     * Verifica o valor informado e o resultante
     * @param saldo - saldo a ser sacado
     * @throws SaldoInvalidoException - em caso de saldo inválido
     */
    public void sacarValor(double saldo) throws SaldoInvalidoException{
        verificaSaldo(saldo, "O saldo é menor que 0, informe uma quantia válida.");
        double novoSaldo = this.saldo - saldo;
        
        verificaSaldo(
                novoSaldo, 
                String.format(
                    "O novo saldo será menor do que R$%.2f.\nOperação cancelada",
                    getLimite()
                )
        );
        this.saldo = novoSaldo;
    }
    
    // Getter
    public double getSaldo() {
        return this.saldo;
    }
    
    public Pessoa getPessoa(){
       return this.pessoa;
    }
    
    public String getNome(){
        return getPessoa().getNome();
    }
    
    public String getCpfFormatado() {
        return getPessoa().getCpfFormatado();
    }
    
    public String getEndereco() {
        return getPessoa().getEndereco();
    }
    
    public double getLimite(){
        return this.limite;
    }
    
   public String getNumeroContaFormatado() {
       return String.format("%07d", this.nConta);
   }

   public int getNumeroConta() {
       return this.nConta;
   }
    
    // Setter (só para especializações)
    protected void setLimite(double limite) throws IllegalArgumentException{
        if(limite >= 0){
            throw new IllegalArgumentException("Informe um valor negativo");
        }
        this.limite = limite;
    }
    
    /**
     * Método que retorna o status atual da conta
     * @return - status atual da conta
     */
    public String consultarStatus(){
        StringBuilder sb = new StringBuilder();
        
        sb.append("Número da Conta: ").append(getNumeroContaFormatado()); 
        sb.append("\nTipo de conta: ").append(getTipoConta());
        
        if(!getTipoConta().equals("ContaBancaria")) // Só mostra limite caso for especial
            sb.append("\nLimite especial: R$").append(getLimite());
        
        sb.append("\nTitular da conta: ").append(getNome());
        sb.append("\nCPF do titular: ").append(getCpfFormatado());
        sb.append("\nEndereço do titular: ").append(getEndereco());
        sb.append("\nSaldo atual: R$").append(getSaldo());
        
        return sb.toString();
    }
    
    /**
     * Método que retorna o tipo da conta específica
     * @return - nome do tipo da conta
     */
    public String getTipoConta(){
        return this.getClass().getSimpleName();
    }
}
