package br.univates.sistemabancario;

import br.univates.alexandria.exceptions.SaldoInvalidoException;
import br.univates.alexandria.models.Pessoa;
import br.univates.alexandria.tools.Messages;
import br.univates.sistemabancario.business.ContaBancaria;
import br.univates.sistemabancario.business.ContaBancariaEspecial;
import br.univates.sistemabancario.persist.ContaBancariaDAO;
import br.univates.sistemabancario.view.TelaPrincipal;

/**
 * Ponto de entrada da aplicação
 * @author mateu
 */
public class App {
    public static void main(String[] args) {
        ContaBancariaDAO dao = new ContaBancariaDAO();
        
        try{
            Pessoa correntista = new Pessoa("068.268.040-00", "Bruno Silva", "Estrada do Sol, 202");
            
            dao.createAccount(new ContaBancariaEspecial(correntista, 0, -1500));
            dao.createAccount(new ContaBancaria(correntista, 2500));
            dao.createAccount(new ContaBancaria(correntista));
            dao.createAccount(new ContaBancariaEspecial(correntista, 5200.75, -5000));
            dao.createAccount(new ContaBancariaEspecial(correntista, 0, -1500));
        } catch(SaldoInvalidoException e){
            Messages.errorMessage(e);
        }

        TelaPrincipal tp = new TelaPrincipal();
        tp.iniciarMenuContas();
    }
}
