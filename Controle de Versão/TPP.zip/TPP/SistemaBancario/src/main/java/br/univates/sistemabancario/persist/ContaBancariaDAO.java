package br.univates.sistemabancario.persist;
        
import br.univates.alexandria.exceptions.SaldoInvalidoException;
import br.univates.alexandria.tools.Messages;
import br.univates.sistemabancario.business.ContaBancaria;
import br.univates.sistemabancario.business.ContaBancariaEspecial;
import java.util.ArrayList;

/**
 * Classe com a lógica de gravação (inexistente por enquanto)
 * @author mateus.brambilla
 */
public class ContaBancariaDAO {
    private static final ArrayList<ContaBancaria> cbList = new ArrayList<>();
    
    // Getters
    public ArrayList<ContaBancaria> getArray(){
        return cbList;
    }
       
    /**
     * Método que retorna uma conta específica
     * @param i - posição do arraylist
     * @return - ContaBancaria
     */
    public ContaBancaria getAccount(int i){
        return cbList.get(i);
    }
    
    public void createAccount(ContaBancaria cb){
        cbList.add(cb);
    }
}
