package br.univates.alexandria.models;

import br.univates.alexandria.tools.Verificador;

/**
 * Classe responsável por simbolizar uma pessoa simples
 * @author mateus.brambilla
 */
public class Pessoa {
    private final CPF cpf;
    private String nome;
    private String endereco;
    
    /**
     * Construtor que instancia uma pessoa
     * @param cpf - cpf do usuário (é passado para classe cpf)
     * @param nome - nome do usuário
     * @param endereco - endereco do usuário
     */
    public Pessoa(String cpf, String nome, String endereco){
        verificaInputs(nome, endereco);
        
        this.cpf = new CPF(cpf);
        setNome(nome);
        setEndereco(endereco);
    }
    
    /**
     * Método auxiliar que verifica os inputs, para ver se estão vazios
     * @param nome - nome do cliente
     * @param endereco - endereço do cliente
     */
    private void verificaInputs(String nome, String endereco){
        Verificador.verificaVazio(nome, "Nome vazio informado");
        verificaEnderecoInput(endereco);
    }
    
    private void verificaEnderecoInput(String endereco){
        Verificador.verificaVazio(endereco, "Endereço vazio informado");
    }

    // Getters
    public String getEndereco() {
        return this.endereco;
    }

    public String getNome(){
        return this.nome;
    }
    
    public CPF getCPF(){
        return this.cpf;
    }
    
    public String getCpfFormatado(){
        return getCPF().getCpfFormatado();
    }
    
    public String getCpfNumbers(){
        return getCPF().getCpf();
    }
    
    // Setter (só para endereco)
    public void setEndereco(String endereco) {
        if (endereco == null || endereco.trim().isEmpty())
            throw new IllegalArgumentException("Endereço não pode ser vazio.");
        this.endereco = endereco;
    }
    
    public void setNome(String nome) {
        if (nome == null || nome.trim().isEmpty()) 
            throw new IllegalArgumentException("Nome não pode ser vazio.");
        this.nome = nome;
    }
}
